package com.flute.ads.adapter;

import android.app.Activity;
import android.content.Context;
import android.support.annotation.NonNull;
import android.util.Log;
import android.widget.FrameLayout;

import com.flute.ads.common.DataKeys;
import com.flute.ads.mobileads.CustomEventAdView;
import com.flute.ads.mobileads.Flute;
import com.flute.ads.mobileads.FluteErrorCode;
import com.ironsource.mediationsdk.ISBannerSize;
import com.ironsource.mediationsdk.IronSource;
import com.ironsource.mediationsdk.IronSourceBannerLayout;
import com.ironsource.mediationsdk.logger.IronSourceError;
import com.ironsource.mediationsdk.sdk.BannerListener;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;


public class IronSourceBanner extends CustomEventAdView implements BannerListener {
    public static final String APP_ID_KEY = "appId";
    public static final String PLACEMENT_ID_KEY = "placementId";

    private CustomEventAdViewListener mBannerListener;
    private FrameLayout mBannerParentLayout;
    private IronSourceBannerLayout mIronSourceBanner;
    private long mAdLoadTimeStamp;
    private ArrayList<HashMap<String, String>> mAdEvents;
    private String mAdUnitId;
    private String mParams;
    private String appKey, placementId;

    @Override
    protected void loadAdView(final Context context,
                              final CustomEventAdViewListener customEventBannerListener,
                              final Map<String, Object> localExtras,
                              final Map<String, String> serverExtras) {
        mBannerListener = customEventBannerListener;

        mAdUnitId = (String) localExtras.get(DataKeys.AD_UNIT_ID_KEY);
        mParams = serverExtras.toString();

        if (extrasAreValid(serverExtras)) {
            appKey = serverExtras.get(APP_ID_KEY);
            placementId = serverExtras.get(PLACEMENT_ID_KEY);
        } else {
            mBannerListener.onAdViewFailed(FluteErrorCode.ADAPTER_CONFIGURATION_ERROR);
            return;
        }

        if (!Flute.getIsIronSourceInit()) {
            IronSource.init((Activity) context, appKey, IronSource.AD_UNIT.BANNER);
            Flute.setIsIronSourceInit(true);
        }

        mAdLoadTimeStamp = System.currentTimeMillis();
        mAdEvents = new ArrayList<>();
        mAdEvents.add(Flute.getDebugEvent(mAdLoadTimeStamp, "loadAd", ""));

        int width;
        int height;
        if (localExtrasAreValid(localExtras)) {
            width = (int) localExtras.get(DataKeys.AD_WIDTH);
            height = (int) localExtras.get(DataKeys.AD_HEIGHT);
        } else {
            mBannerListener.onAdViewFailed(FluteErrorCode.ADAPTER_CONFIGURATION_ERROR);
            return;
        }

        ISBannerSize size = ISBannerSize.BANNER;

        mIronSourceBanner = IronSource.createBanner((Activity) context, size);
//        FrameLayout.LayoutParams layoutParams = new FrameLayout.LayoutParams(width,
//                height);
//        mBannerParentLayout.addView(mIronSourceBanner, 0, layoutParams);

        if (mIronSourceBanner != null) {
            mIronSourceBanner.setBannerListener(this);
            IronSource.loadBanner(mIronSourceBanner);
        } else {
            Log.d("Flute", "IronSource.createBanner returned null ");
        }
    }

    @Override
    protected void onInvalidate () {
        if (mIronSourceBanner != null) {
            IronSource.destroyBanner(mIronSourceBanner);
        }
        Flute.sendDebugLog("banner", "IronSource", mAdUnitId, mParams, mAdLoadTimeStamp, mAdEvents.toString());

    }

    private boolean localExtrasAreValid(@NonNull final Map<String, Object> localExtras) {
        return localExtras.get(DataKeys.AD_WIDTH) instanceof Integer
                && localExtras.get(DataKeys.AD_HEIGHT) instanceof Integer;
    }

    @Override
    public void onBannerAdLoaded() {
        if (mIronSourceBanner == null) {
            return;
        }

        if (mBannerListener != null) {
            mBannerListener.onAdViewLoaded(mIronSourceBanner);
        }

        mAdEvents.add(Flute.getDebugEvent(System.currentTimeMillis(), "onBannerLoaded", ""));

    }

    @Override
    public void onBannerAdLoadFailed(IronSourceError ironSourceError) {
        if (mBannerListener != null) {
            mBannerListener.onAdViewFailed(FluteErrorCode.NETWORK_NO_FILL);
        }

        mAdEvents.add(Flute.getDebugEvent(System.currentTimeMillis(), "onBannerFailed", ironSourceError.toString()));

    }

    @Override
    public void onBannerAdClicked() {
        if (mBannerListener != null) {
            mBannerListener.onAdViewClicked();
        }

        mAdEvents.add(Flute.getDebugEvent(System.currentTimeMillis(), "onBannerClicked", ""));

    }

    @Override
    public void onBannerAdScreenPresented() {

    }

    @Override
    public void onBannerAdScreenDismissed() {
        mAdEvents.add(Flute.getDebugEvent(System.currentTimeMillis(), "onBannerDismissed", ""));
    }

    @Override
    public void onBannerAdLeftApplication() {

    }

    private boolean extrasAreValid(final Map<String, String> serverExtras) {
        return serverExtras.containsKey(APP_ID_KEY);
    }
}