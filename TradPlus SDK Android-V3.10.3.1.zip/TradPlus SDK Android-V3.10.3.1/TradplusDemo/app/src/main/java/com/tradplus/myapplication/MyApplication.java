package com.tradplus.myapplication;

import android.app.Application;

import com.flute.ads.mobileads.Flute;

public class MyApplication extends Application {

    @Override
    public void onCreate() {
        super.onCreate();
        //初始化SDK
        Flute.invoker().initPub(this);
    }
}
