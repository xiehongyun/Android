package com.tradplus.myapplication;

import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import androidx.appcompat.app.AppCompatActivity;
import com.flute.ads.mobileads.FluteErrorCode;
import com.flute.ads.mobileads.FluteView;

public class MainActivity extends AppCompatActivity {

    FluteView mFluteView, mFluteNativeView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        //需要现在APP启动的地方，初始化SDK
        //加载banner
        loadBanner();
        //加载原生广告
        loadNative();

    }

    public void loadBanner() {
        Button banner_btn = (Button)findViewById(R.id.banner_ad);
        banner_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mFluteView = findViewById(R.id.BannerView);
                mFluteView.setAdUnitId("A24091715B4FCD50C0F2039A5AF7C4BB");//测试使用
                mFluteView.setAdViewListener(new FluteView.FSAdViewListener() {
                    //广告加载成功
                    @Override
                    public void onAdViewLoaded(final FluteView tradPlusView) {
                        Log.d("Flute","Banner loaded SuccessFull!!");

                        runOnUiThread(new Runnable() {
                            @Override
                            public void run() {
                                //广告渠道
                                String channelName = tradPlusView.getChannelName();
                                //广告位ID
                                String adUnitId = tradPlusView.getAdUnitId();

                            }
                        });
                    }

                    //广告加载失败
                    @Override
                    public void onAdViewFailed(final FluteView tradPlusView, final FluteErrorCode tradPlusErrorCode) {
                        Log.d("Flute","Banner loaded  Failed!!!");
                        runOnUiThread(new Runnable() {
                            @Override
                            public void run() {
                                String channelName = tradPlusView.getChannelName();
                                String adUnitId = tradPlusView.getAdUnitId();
                            }
                        });
                    }

                    @Override
                    public void onAdViewClicked(FluteView tradPlusView) {

                    }

                    @Override
                    public void onAdViewExpanded(FluteView tradPlusView) {

                    }

                    @Override
                    public void onAdViewCollapsed(FluteView tradPlusView) {

                    }
                });

                mFluteView.loadAd();
            }
        });
    }

    public void loadNative() {
        Button native_ad = (Button)findViewById(R.id.native_ad);
        native_ad.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mFluteNativeView = findViewById(R.id.NativeView);
                mFluteNativeView.setAdUnitId("DDBF26FBDA47FBE2765F1A089F1356BF");//测试使用
                mFluteNativeView.setAdLayoutName("native_ad_list_item");
                mFluteNativeView.setAdViewListener(new FluteView.FSAdViewListener() {
                    //广告加载成功
                    @Override
                    public void onAdViewLoaded(final FluteView banner) {
                        Log.d("Tradplus","Native loaded SuccessFull!!!");
                        runOnUiThread(new Runnable() {
                            @Override
                            public void run() {
                                String channelName = banner.getChannelName();
                                String adUnitId = banner.getAdUnitId();
                            }
                        });
                    }

                    //广告加载失败
                    @Override
                    public void onAdViewFailed(final FluteView banner, FluteErrorCode errorCode) {
                        Log.d("Tradplus","Native loaded Failed!!!");
                        runOnUiThread(new Runnable() {
                            @Override
                            public void run() {
                                String channelName = banner.getChannelName();
                                String adUnitId = banner.getAdUnitId();
                            }
                        });

                    }

                    @Override
                    public void onAdViewClicked(FluteView banner) {

                    }

                    @Override
                    public void onAdViewExpanded(FluteView banner) {

                    }

                    @Override
                    public void onAdViewCollapsed(FluteView banner) {

                    }
                });

                mFluteNativeView.loadAd();

            }
        });
    }

    @Override
    protected void onDestroy() {
        if (mFluteView != null ) {
            mFluteView.destroy();
        }

        if (mFluteNativeView!= null) {
            mFluteNativeView.destroy();
        }
        super.onDestroy();
    }
}
